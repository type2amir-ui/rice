<?php
/**
 * Main Entry Template - Hashir Rice Supplier
 */
if (!defined('ABSPATH')) { exit; }
if (is_front_page() || is_home()) {
  include get_template_directory() . '/front-page.php';
} else {
  include get_template_directory() . '/page.php';
}
