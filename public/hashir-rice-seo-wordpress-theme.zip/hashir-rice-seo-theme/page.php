<?php
/**
 * The template for displaying all pages - Hashir Rice Supplier
 */
if (!defined('ABSPATH')) { exit; }
get_header();

$req_path = isset($_SERVER['REQUEST_URI']) ? trim(strtok($_SERVER['REQUEST_URI'], '?'), '/') : '';
$seed_page = function_exists('hashir_find_seed_page_by_slug') ? hashir_find_seed_page_by_slug($req_path) : null;

$page_title = get_the_title();
$page_desc  = '';
$page_html_content = '';

if (have_posts()) {
  while (have_posts()) {
    the_post();
    $raw_c = get_the_content();
    if (strlen(trim($raw_c)) > 50) {
      $page_html_content = apply_filters('the_content', $raw_c);
    }
    $page_desc = get_the_excerpt();
  }
}

if (!$page_html_content && $seed_page && !empty($seed_page['content'])) {
  $page_html_content = $seed_page['content'];
  if (!empty($seed_page['meta_desc'])) $page_desc = $seed_page['meta_desc'];
  if (!empty($seed_page['title'])) $page_title = $seed_page['title'];
}
?>
<main id="main-content" class="py-12 bg-stone-50">
  <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
    <nav aria-label="Breadcrumb" class="text-xs text-neutral-500 mb-6 flex items-center gap-2">
      <a href="<?php echo esc_url(home_url('/')); ?>" class="hover:text-emerald-800">Home</a>
      <span>&gt;</span>
      <span class="text-neutral-800 font-medium"><?php echo esc_html($page_title); ?></span>
    </nav>

    <article class="bg-white rounded-2xl border border-stone-200 p-8 sm:p-12 shadow-sm">
      <header class="border-b border-stone-200 pb-6 mb-8">
        <h1 class="font-serif text-2xl sm:text-3xl lg:text-4xl font-extrabold text-emerald-950 leading-tight">
          <?php echo esc_html($page_title); ?>
        </h1>
        <?php if ($page_desc) : ?>
          <p class="text-sm sm:text-base text-neutral-600 mt-3 leading-relaxed">
            <?php echo esc_html($page_desc); ?>
          </p>
        <?php endif; ?>
      </header>

      <div class="prose prose-emerald max-w-none text-neutral-800 leading-relaxed text-sm sm:text-base">
        <?php if ($page_html_content) : ?>
          <?php echo $page_html_content; ?>
        <?php else : ?>
          <p>Direct ex-mill wholesale rice dispatch from Noor Galla Mandi, Bucheki (Nankana Sahib, Punjab). Bulk 1121 Kainat Steam, Sella &amp; Super Kernel Basmati bilty delivery nationwide.</p>
        <?php endif; ?>
      </div>

      <div class="mt-12 p-6 rounded-xl bg-emerald-900 text-white flex flex-col sm:flex-row justify-between items-center gap-4">
        <div>
          <strong class="block text-base font-bold text-amber-300">Need Bulk Rice Rates for This City / Variety?</strong>
          <span class="text-xs text-emerald-100">Direct ex-mill spot rate quotes &amp; free 500g physical samples available.</span>
        </div>
        <div class="flex items-center gap-3">
          <a href="https://wa.me/923338990883?text=Inquiry%20regarding%20<?php echo urlencode($page_title); ?>" target="_blank" class="bg-amber-400 hover:bg-amber-500 text-neutral-950 text-xs font-bold py-2.5 px-4 rounded-lg transition whitespace-nowrap">
            WhatsApp Rate &rarr;
          </a>
          <a href="<?php echo esc_url(home_url('/sample-request')); ?>" class="bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-bold py-2.5 px-4 rounded-lg transition border border-emerald-600 whitespace-nowrap">
            Sample Request
          </a>
        </div>
      </div>
    </article>
  </div>
</main>
<?php
get_footer();
