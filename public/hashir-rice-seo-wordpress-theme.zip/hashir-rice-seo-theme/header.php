<?php
/**
 * Header Template - Hashir Rice Supplier
 */
if (!defined('ABSPATH')) { exit; }
$theme_uri = get_template_directory_uri();
$site_url = home_url('/');
?><!doctype html>
<html <?php language_attributes(); ?> class="scroll-smooth">
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,600;0,700;0,800;1,600&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <script>
    window.__WP_THEME_URI__ = '<?php echo esc_js($theme_uri); ?>';
    window.__WP_SITE_URL__ = '<?php echo esc_js($site_url); ?>';
  </script>
  <?php wp_head(); ?>
  <link rel="stylesheet" href="<?php echo esc_url($theme_uri . '/assets/app.css'); ?>?v=6.4.0">
</head>
<body <?php body_class('bg-stone-50 text-neutral-900 font-sans antialiased selection:bg-emerald-900 selection:text-amber-300'); ?>>
<?php if (function_exists('wp_body_open')) { wp_body_open(); } ?>

<div id="root">

<!-- Top Mandi Announcement Bar (Exact Google Studio Match) -->
<div class="bg-neutral-50 text-neutral-700 text-xs py-1.5 sm:py-2 px-3 sm:px-4 border-b border-neutral-200">
  <div class="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-1.5 sm:gap-2">
    <div class="flex items-center justify-center md:justify-start gap-2 text-xs tracking-wide text-center">
      <span class="inline-flex items-center gap-1.5 font-semibold text-emerald-900">
        <span class="w-2 h-2 rounded-full bg-emerald-600 animate-pulse"></span>
        Direct Mandi Sourcing Desk:
      </span>
      <span class="hidden lg:inline text-neutral-300">•</span>
      <span class="text-neutral-600">Noor Galla Mandi, Bucheki (Nankana Sahib, Punjab)</span>
    </div>

    <div class="flex flex-wrap items-center justify-center md:justify-end gap-1.5 sm:gap-2 text-xs font-medium">
      <!-- Social Media Quick Links -->
      <div class="hidden sm:flex items-center gap-1.5 pr-2 border-r border-neutral-300">
        <a href="https://www.facebook.com/hashirricesupplier" target="_blank" rel="noopener noreferrer" aria-label="Facebook" title="Facebook" class="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-white hover:bg-emerald-900 hover:text-white text-neutral-600 border border-neutral-200 hover:border-emerald-900 flex items-center justify-center transition-colors">
          <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
        </a>
        <a href="https://www.instagram.com/hashirricesuppliers/" target="_blank" rel="noopener noreferrer" aria-label="Instagram" title="Instagram" class="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-white hover:bg-emerald-900 hover:text-white text-neutral-600 border border-neutral-200 hover:border-emerald-900 flex items-center justify-center transition-colors">
          <svg class="w-3 h-3" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect width="20" height="20" x="2" y="2" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/></svg>
        </a>
        <a href="https://www.tiktok.com/@hashirricesuppliers" target="_blank" rel="noopener noreferrer" aria-label="TikTok" title="TikTok" class="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-white hover:bg-emerald-900 hover:text-white text-neutral-600 border border-neutral-200 hover:border-emerald-900 flex items-center justify-center transition-colors">
          <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 24 24"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64c.298-.002.595.042.88.13V9.4a6.33 6.33 0 0 0-1-.08A6.34 6.34 0 0 0 3 15.66a6.34 6.34 0 0 0 10.86 4.46V10.4a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-.04-1.83z"/></svg>
        </a>
        <a href="https://www.linkedin.com/company/hashir-rice-supplier/" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn" title="LinkedIn" class="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-white hover:bg-emerald-900 hover:text-white text-neutral-600 border border-neutral-200 hover:border-emerald-900 flex items-center justify-center transition-colors">
          <svg class="w-3 h-3" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect width="4" height="12" x="2" y="9"/><circle cx="4" cy="4" r="2"/></svg>
        </a>
      </div>

      <a href="https://share.google/Xog0BKr0oU1NiGIUL" target="_blank" rel="noopener noreferrer" class="inline-flex items-center gap-1 text-emerald-800 hover:text-emerald-950 transition-colors font-medium whitespace-nowrap px-1.5 py-0.5 rounded hover:bg-emerald-50">
        <svg class="w-3.5 h-3.5 text-emerald-700 shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
        <span class="hidden sm:inline">Google Business Profile</span>
        <span class="sm:hidden">Google Profile</span>
      </a>
      <span class="text-neutral-300 hidden sm:inline">|</span>
      <div class="flex items-center gap-1 sm:gap-1.5 flex-wrap justify-center">
        <a href="https://wa.me/923338990883?text=Hello%20Hashir%20Rice%20Supplier,%20I%20am%20interested%20in%20bulk%20rice%20sourcing." target="_blank" rel="noopener noreferrer" title="WhatsApp Desk 1" class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-100/70 hover:bg-emerald-200/80 text-emerald-950 font-bold transition-colors whitespace-nowrap border border-emerald-300/60 text-[11px] sm:text-xs">
          <svg viewBox="0 0 24 24" fill="currentColor" class="w-3.5 h-3.5 text-emerald-700 shrink-0"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.888 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
          <span>+92 333 8990883</span>
        </a>
        <a href="https://wa.me/923002861297?text=Hello%20Hashir%20Rice%20Supplier,%20I%20am%20interested%20in%20bulk%20rice%20sourcing." target="_blank" rel="noopener noreferrer" title="WhatsApp Desk 2" class="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-100/70 hover:bg-emerald-200/80 text-emerald-950 font-bold transition-colors whitespace-nowrap border border-emerald-300/60 text-[11px] sm:text-xs">
          <svg viewBox="0 0 24 24" fill="currentColor" class="w-3.5 h-3.5 text-emerald-700 shrink-0"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.888 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
          <span>+92 300 2861297</span>
        </a>
      </div>
    </div>
  </div>
</div>

<!-- Main Sticky Header Navigation (Exact Google Studio Match) -->
<nav class="sticky top-0 z-50 w-full bg-white/95 backdrop-blur-md transition-all duration-200 border-b border-neutral-200/80 py-3.5 shadow-xs">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-3">
    <!-- Brand Logo -->
    <a href="<?php echo esc_url($site_url); ?>" class="flex items-center gap-2.5 text-left group shrink-0">
      <div class="relative inline-flex items-center shrink-0">
        <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-10 h-10 shrink-0 drop-shadow-sm">
          <defs>
            <linearGradient id="hdrBgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#064E3B"/>
              <stop offset="45%" stop-color="#04392B"/>
              <stop offset="100%" stop-color="#022119"/>
            </linearGradient>
            <linearGradient id="hdrBorderGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#34D399" stop-opacity="0.45"/>
              <stop offset="50%" stop-color="#10B981" stop-opacity="0.15"/>
              <stop offset="100%" stop-color="#059669" stop-opacity="0.05"/>
            </linearGradient>
            <linearGradient id="hdrGoldGrad" x1="0%" y1="100%" x2="100%" y2="0%">
              <stop offset="0%" stop-color="#D97706"/>
              <stop offset="35%" stop-color="#F59E0B"/>
              <stop offset="75%" stop-color="#FBBF24"/>
              <stop offset="100%" stop-color="#FFFBEB"/>
            </linearGradient>
          </defs>
          <rect x="4" y="4" width="92" height="92" rx="22" fill="url(#hdrBgGrad)" stroke="url(#hdrBorderGrad)" stroke-width="1.5"/>
          <rect x="27" y="25" width="11" height="50" rx="5.5" fill="#FFFFFF"/>
          <rect x="62" y="25" width="11" height="50" rx="5.5" fill="#FFFFFF"/>
          <path d="M38 50 C44 43, 56 43, 62 50 C56 57, 44 57, 38 50 Z" fill="url(#hdrGoldGrad)"/>
          <path d="M43 50 C47 41, 53 41, 57 50" stroke="#FFFFFF" stroke-width="1.5" stroke-linecap="round"/>
          <circle cx="50" cy="36" r="3.5" fill="url(#hdrGoldGrad)"/>
        </svg>
      </div>
      <div class="shrink-0">
        <div class="flex items-center gap-1.5 leading-none">
          <span class="font-sans text-base sm:text-lg font-black tracking-tight text-neutral-950 group-hover:text-emerald-900 transition-colors whitespace-nowrap">HASHIR</span>
          <span class="font-sans text-base sm:text-lg font-black tracking-tight text-amber-600 group-hover:text-amber-700 transition-colors whitespace-nowrap">RICE</span>
          <span class="hidden sm:inline-block text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-900 tracking-wider">SUPPLIER</span>
        </div>
        <p class="text-[9.5px] font-bold tracking-wider uppercase text-emerald-800 mt-1 whitespace-nowrap">Wholesale Supplier • Bucheki Mandi</p>
      </div>
    </a>

    <!-- Desktop Nav Links -->
    <div class="hidden lg:flex items-center gap-1 xl:gap-2">
      <a href="<?php echo esc_url($site_url); ?>" class="px-2.5 xl:px-3 py-1.5 text-xs xl:text-sm font-semibold rounded-md text-emerald-950 bg-emerald-100/80 border border-emerald-300">Home</a>
      <a href="<?php echo esc_url(home_url('/about-us')); ?>" class="px-2.5 xl:px-3 py-1.5 text-xs xl:text-sm font-medium rounded-md text-neutral-700 hover:text-emerald-950 hover:bg-neutral-100 transition-colors">About Us</a>
      <a href="<?php echo esc_url(home_url('/varieties')); ?>" class="px-2.5 xl:px-3 py-1.5 text-xs xl:text-sm font-medium rounded-md text-neutral-700 hover:text-emerald-950 hover:bg-neutral-100 transition-colors">Rice Catalog</a>
      <a href="<?php echo esc_url(home_url('/locations')); ?>" class="px-2.5 xl:px-3 py-1.5 text-xs xl:text-sm font-medium rounded-md text-neutral-700 hover:text-emerald-950 hover:bg-neutral-100 transition-colors">Major Cities</a>
      <a href="<?php echo esc_url(home_url('/exchange')); ?>" class="px-2.5 xl:px-3 py-1.5 text-xs xl:text-sm font-semibold rounded-md text-emerald-900 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 transition-colors inline-flex items-center gap-1.5">
        <span class="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse"></span>
        <span>Market Index</span>
      </a>
      <a href="<?php echo esc_url(home_url('/contact')); ?>" class="px-2.5 xl:px-3 py-1.5 text-xs xl:text-sm font-medium rounded-md text-neutral-700 hover:text-emerald-950 hover:bg-neutral-100 transition-colors">Contact</a>
    </div>

    <!-- Action CTAs -->
    <div class="hidden lg:flex items-center gap-2 shrink-0">
      <a href="https://trade.hashirricesupplier.com/" target="_blank" rel="noopener noreferrer" class="inline-flex items-center gap-1.5 px-3 py-2 text-xs xl:text-sm font-bold rounded-lg bg-red-600 hover:bg-red-700 text-white shadow-xs hover:shadow transition-all active:scale-[0.98] whitespace-nowrap cursor-pointer shrink-0">
        <span>+ Add Rice Sample Free</span>
        <svg class="w-3 h-3 opacity-80 shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" x2="21" y1="14" y2="3"/></svg>
      </a>

      <a href="https://wa.me/923338990883?text=Assalam-o-Alaikum%20Hashir%20Rice,%20I%20want%20to%20inquire%20about%20today%27s%20wholesale%20rates" target="_blank" rel="noopener noreferrer" class="inline-flex items-center gap-1.5 px-3 py-2 text-xs xl:text-sm font-bold rounded-lg bg-emerald-900 hover:bg-emerald-950 text-white shadow-xs hover:shadow transition-all active:scale-[0.98] whitespace-nowrap cursor-pointer shrink-0">
        <svg class="w-3.5 h-3.5 text-amber-300 shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 2v2m0 16v2M4.93 4.93l1.41 1.41m11.32 11.32l1.41 1.41M2 12h2m16 0h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/></svg>
        <span>Mandi Rate Inquiry</span>
      </a>

      <a href="https://wa.me/923338990883?text=Hello%20Hashir%20Rice%20Supplier,%20I%20want%20to%20inquire%20about%20wholesale%20rice%20rates." target="_blank" rel="noopener noreferrer" class="inline-flex items-center gap-1.5 px-3 py-2 text-xs xl:text-sm font-semibold rounded-lg bg-emerald-50 text-emerald-950 hover:bg-emerald-100 border border-emerald-300/80 transition-colors whitespace-nowrap cursor-pointer shrink-0">
        <svg viewBox="0 0 24 24" fill="currentColor" class="w-4 h-4 text-emerald-700 shrink-0"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.888 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
        <span>WhatsApp</span>
      </a>
    </div>

    <!-- Mobile Menu Button -->
    <div class="flex lg:hidden items-center gap-2">
      <a href="https://trade.hashirricesupplier.com/" target="_blank" rel="noopener noreferrer" class="px-2.5 py-1.5 rounded-lg bg-red-600 text-white font-bold text-xs">
        + Sample
      </a>
      <a href="https://wa.me/923338990883" target="_blank" class="p-2 text-emerald-800 font-bold text-xs bg-emerald-50 rounded-lg">
        💬 Chat
      </a>
      <button type="button" id="mobile-menu-toggle" class="p-2 rounded-lg text-neutral-700 hover:bg-stone-100 border border-stone-200" aria-label="Toggle menu">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
      </button>
    </div>
  </div>

  <div id="mobile-nav-panel" class="hidden lg:hidden border-t border-neutral-200 bg-white px-4 py-4 space-y-2">
    <a href="<?php echo esc_url($site_url); ?>" class="block px-3 py-2 rounded-lg text-base font-semibold text-neutral-800 hover:bg-stone-100">Home</a>
    <a href="<?php echo esc_url(home_url('/about-us')); ?>" class="block px-3 py-2 rounded-lg text-base font-semibold text-neutral-800 hover:bg-stone-100">About Founder &amp; Bucheki Mandi</a>
    <a href="<?php echo esc_url(home_url('/varieties')); ?>" class="block px-3 py-2 rounded-lg text-base font-semibold text-neutral-800 hover:bg-stone-100">Rice Varieties Catalog</a>
    <a href="<?php echo esc_url(home_url('/exchange')); ?>" class="block px-3 py-2 rounded-lg text-base font-semibold text-emerald-800 hover:bg-stone-100">Live Mandi Rates &amp; Spot Prices</a>
    <a href="<?php echo esc_url(home_url('/locations')); ?>" class="block px-3 py-2 rounded-lg text-base font-semibold text-neutral-800 hover:bg-stone-100">60+ Cities Delivery Network</a>
    <a href="<?php echo esc_url(home_url('/workflow')); ?>" class="block px-3 py-2 rounded-lg text-base font-semibold text-neutral-800 hover:bg-stone-100">7-Stage Quality Sourcing Workflow</a>
    <a href="<?php echo esc_url(home_url('/sample-request')); ?>" class="block px-3 py-2 rounded-lg text-base font-semibold text-amber-700 hover:bg-stone-100">Request Physical Cooking Sample</a>
    <a href="https://trade.hashirricesupplier.com/" target="_blank" rel="noopener noreferrer" class="block px-3 py-2 rounded-lg text-base font-bold text-white bg-red-600 hover:bg-red-700 text-center mt-2">+ Add Rice Sample Free</a>
    <a href="<?php echo esc_url(home_url('/contact')); ?>" class="block px-3 py-2 rounded-lg text-base font-semibold text-neutral-800 hover:bg-stone-100">Contact Bucheki Dispatch Desk</a>
  </div>
</nav>
