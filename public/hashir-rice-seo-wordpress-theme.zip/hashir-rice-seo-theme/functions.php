<?php
if (!defined('ABSPATH')) {
  exit;
}

// Polyfill mbstring functions if extension is not installed
if (!function_exists('mb_strlen')) {
  function mb_strlen($str, $encoding = 'UTF-8') {
    return strlen($str);
  }
}
if (!function_exists('mb_substr')) {
  function mb_substr($str, $start, $length = null, $encoding = 'UTF-8') {
    return $length === null ? substr($str, $start) : substr($str, $start, $length);
  }
}
if (!function_exists('mb_strrpos')) {
  function mb_strrpos($haystack, $needle, $offset = 0, $encoding = 'UTF-8') {
    return strrpos($haystack, $needle, $offset);
  }
}
if (!function_exists('mb_stripos')) {
  function mb_stripos($haystack, $needle, $offset = 0, $encoding = 'UTF-8') {
    return stripos($haystack, $needle, $offset);
  }
}
if (!function_exists('mb_strtolower')) {
  function mb_strtolower($str, $encoding = 'UTF-8') {
    return strtolower($str);
  }
}

if (file_exists(get_template_directory() . '/inc/all-pages-seed.php')) {
  require_once get_template_directory() . '/inc/all-pages-seed.php';
}

function hashir_theme_setup() {
  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'));
  register_nav_menus(array(
    'primary' => 'Primary Navigation Menu',
    'footer'  => 'Footer Navigation Menu'
  ));
}
add_action('after_setup_theme', 'hashir_theme_setup');

function hashir_enqueue_theme_assets() {
  wp_enqueue_style('hashir-theme-style', get_stylesheet_uri(), array(), '6.3.0');
  wp_enqueue_style('hashir-tailwind-app', get_template_directory_uri() . '/assets/app.css', array(), '6.3.0');
  wp_enqueue_script('hashir-theme-app', get_template_directory_uri() . '/assets/app.js', array(), '6.3.0', true);
}
add_action('wp_enqueue_scripts', 'hashir_enqueue_theme_assets', 20);

// Ensure modern React bundle loads as ES module so React mounts without syntax errors
add_filter('script_loader_tag', function($tag, $handle, $src) {
  if ($handle === 'hashir-theme-app') {
    return '<script type="module" crossorigin src="' . esc_url($src) . '"></script>' . "
";
  }
  return $tag;
}, 10, 3);

function hashir_on_theme_activation() {
  update_option('blog_public', '1');
  if (get_option('permalink_structure') !== '/%postname%/') {
    update_option('permalink_structure', '/%postname%/');
  }
  if (function_exists('set_time_limit')) { @set_time_limit(300); }
  @ini_set('memory_limit', '512M');
  if (function_exists('hashir_seed_or_repair_all_wordpress_pages')) {
    hashir_seed_or_repair_all_wordpress_pages(false);
  }
  $home_page = get_page_by_path('home', OBJECT, 'page');
  if ($home_page) {
    update_option('show_on_front', 'page');
    update_option('page_on_front', $home_page->ID);
  }
  flush_rewrite_rules();
}
add_action('after_switch_theme', 'hashir_on_theme_activation');

// Auto-seed all 120 pages on fresh WordPress installs upon admin login if not seeded yet
add_action('admin_init', function() {
  if (current_user_can('manage_options') && !get_option('hashir_v5_real_text_seeded_count')) {
    if (function_exists('set_time_limit')) { @set_time_limit(300); }
    @ini_set('memory_limit', '512M');
    if (function_exists('hashir_seed_or_repair_all_wordpress_pages')) {
      hashir_seed_or_repair_all_wordpress_pages(false);
    }
    $home_page = get_page_by_path('home', OBJECT, 'page');
    if ($home_page) {
      update_option('show_on_front', 'page');
      update_option('page_on_front', $home_page->ID);
    }
    flush_rewrite_rules();
  }
});

function hashir_handle_admin_sync_action() {
  if (is_admin() && current_user_can('manage_options') && isset($_GET['hashir_populate_real_text'])) {
    check_admin_referer('hashir_populate_nonce');
    $count = hashir_seed_or_repair_all_wordpress_pages(true);
    $trashed = hashir_auto_trash_duplicate_wordpress_pages();
    wp_redirect(admin_url('edit.php?post_type=page&hashir_seeded=' . intval($count) . '&hashir_trashed=' . intval($trashed)));
    exit;
  }
  if (is_admin() && current_user_can('manage_options') && isset($_GET['hashir_trash_duplicates_now'])) {
    check_admin_referer('hashir_trash_dup_nonce');
    $trashed = hashir_auto_trash_duplicate_wordpress_pages();
    wp_redirect(admin_url('edit.php?post_status=trash&post_type=page&hashir_trashed=' . intval($trashed)));
    exit;
  }
}
add_action('admin_init', 'hashir_handle_admin_sync_action');

function hashir_admin_real_text_notice() {
  if (!current_user_can('manage_options')) return;
  $sync_url = wp_nonce_url(admin_url('edit.php?post_type=page&hashir_populate_real_text=1'), 'hashir_populate_nonce');
  $seeded_msg = isset($_GET['hashir_seeded']) ? intval($_GET['hashir_seeded']) : 0;
  ?>
  <div class="notice notice-success is-dismissible" style="border-left-color:#047857;padding:12px 16px;">
    <p style="margin:0 0 8px 0;font-size:14px;">
      <strong>Hashir Rice Supplier Theme (v6.0 to 100% Original Design Restored + Real Editor Text):</strong>
      <?php if ($seeded_msg > 0) : ?>
        <span style="color:#047857;font-weight:bold;">Successfully populated <?php echo esc_html($seeded_msg); ?> pages with 100% Real Text &amp; HTML in the WordPress Editor!</span>
      <?php else : ?>
        Original React Website Design is active on the frontend, and all <?php echo count(hashir_get_all_real_text_pages_data()); ?> Pages contain full Real Text &amp; HTML in the WordPress Editor.
      <?php endif; ?>
    </p>
    <p style="margin:0;">
      <a href="<?php echo esc_url($sync_url); ?>" class="button button-primary" style="background:#047857;border-color:#065f46;">
        Populate / Repair All <?php echo count(hashir_get_all_real_text_pages_data()); ?> Pages Real Text in Editor
      </a>
      <a href="<?php echo esc_url(home_url('/sitemap.xml')); ?>" target="_blank" class="button" style="margin-left:8px;">
        View Live XML Sitemap
      </a>
    </p>
  </div>
  <?php
}
add_action('admin_notices', 'hashir_admin_real_text_notice');

// Disable default WP core wp-sitemap.xml from injecting wp-sitemap.xml into robots.txt
add_filter('wp_sitemaps_enabled', '__return_false');

// Prevent WordPress redirect_canonical from issuing 301 redirects on pages/posts
add_filter('redirect_canonical', '__return_false', 99999);
remove_action('template_redirect', 'redirect_canonical');
add_filter('do_redirect_guess_404_permalink', '__return_false', 99999);

// Force WordPress & RankMath robots_txt filter to always output https://hashirricesupplier.com/sitemap.xml
add_filter('robots_txt', function($output, $public) {
  $clean_robots  = "User-agent: *\n";
  $clean_robots .= "Allow: /\n";
  $clean_robots .= "Disallow: /wp-admin/\n";
  $clean_robots .= "Allow: /wp-admin/admin-ajax.php\n\n";
  $clean_robots .= "Sitemap: " . esc_url(home_url('/sitemap.xml')) . "\n";
  return $clean_robots;
}, 99999, 2);

// Send all HTTP Security Headers (including HSTS) & 200 OK early at init + send_headers
function hashir_send_all_security_headers() {
  if (!headers_sent()) {
    header('Strict-Transport-Security: max-age=31536000; includeSubDomains; preload', true);
    header('X-Frame-Options: SAMEORIGIN', true);
    header('X-Content-Type-Options: nosniff', true);
    header('Referrer-Policy: strict-origin-when-cross-origin', true);
    header("Content-Security-Policy: upgrade-insecure-requests; frame-ancestors 'self'", true);
    header('X-Robots-Tag: index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1', true);
  }
}
add_action('init', 'hashir_send_all_security_headers', -99999);
add_action('send_headers', 'hashir_send_all_security_headers', 1);

// Built-in Dynamic XML Sitemap at /sitemap.xml & /robots.txt for Google Search Console
function hashir_serve_dynamic_sitemap() {
  $req_uri = isset($_SERVER['REQUEST_URI']) ? strtok($_SERVER['REQUEST_URI'], '?') : '';
  if ($req_uri === '/robots.txt') {
    status_header(200);
    hashir_send_all_security_headers();
    header('Content-Type: text/plain; charset=utf-8', true);
    echo "User-agent: *\n";
    echo "Allow: /\n";
    echo "Disallow: /wp-admin/\n";
    echo "Allow: /wp-admin/admin-ajax.php\n\n";
    echo "Sitemap: " . esc_url(home_url('/sitemap.xml')) . "\n";
    exit;
  }
  if ($req_uri === '/wp-sitemap.xml' || $req_uri === '/sitemap_index.xml' || $req_uri === '/page-sitemap.xml' || $req_uri === '/post-sitemap.xml' || $req_uri === '/wp-sitemap-posts-page-1.xml' || $req_uri === '/wp-sitemap-posts-post-1.xml') {
    header('HTTP/1.1 301 Moved Permanently');
    header('Location: ' . esc_url(home_url('/sitemap.xml')));
    exit;
  }
  if ($req_uri === '/sitemap.xml' || $req_uri === '/wp-sitemap-all.xml') {
    status_header(200);
    hashir_send_all_security_headers();
    header('Content-Type: application/xml; charset=utf-8', true);
    echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
    echo '  <url><loc>' . esc_url(home_url('/')) . '</loc><lastmod>' . date('Y-m-d') . '</lastmod><changefreq>daily</changefreq><priority>1.00</priority></url>' . "\n";

    $seen = array(
      'home' => true,
      'about' => true,
      'about-2' => true,
      'sample' => true,
      'samples' => true,
      'seller' => true,
      'seller-exchange' => true,
      'seller-samples' => true,
      'privacy' => true,
      'terms' => true,
      'contact-us' => true,
      'faq' => true,
      'sample-page' => true,
      'wordpress-download-files' => true,
      'download-wordpress-files' => true,
      'download-files' => true,
      'brand-assets' => true,
      'media-kit' => true,
      'logos' => true,
      'download-logo' => true
    );

    // Collect all trashed page base slugs so trashed pages are 100% excluded from sitemap.xml
    $trashed_pages = get_posts(array(
      'post_type'      => array('page', 'post'),
      'post_status'    => 'trash',
      'posts_per_page' => -1,
    ));
    foreach ($trashed_pages as $tp) {
      $tslug = preg_replace('/__trashed$/i', '', strtolower(trim($tp->post_name)));
      if ($tslug) {
        $seen[$tslug] = true;
      }
    }

    $wp_posts = get_posts(array('post_type' => 'post', 'post_status' => 'publish', 'numberposts' => 200));
    foreach ($wp_posts as $wp_post) {
      $slug = strtolower(trim($wp_post->post_name));
      if (!$slug || isset($seen[$slug]) || strpos($slug, '__trashed') !== false || preg_match('/-(2|3|4|5|6|7|8|9|copy|duplicate)$/i', $slug)) continue;
      $seen[$slug] = true;
      $loc = rtrim(get_permalink($wp_post->ID), '/');
      echo '  <url><loc>' . esc_url($loc) . '</loc><lastmod>' . get_the_modified_date('Y-m-d', $wp_post->ID) . '</lastmod><changefreq>daily</changefreq><priority>0.90</priority></url>' . "\n";
    }

    $wp_pages = get_pages(array('post_status' => 'publish'));
    foreach ($wp_pages as $wp_p) {
      $slug = strtolower(trim($wp_p->post_name));
      if (!$slug || isset($seen[$slug]) || strpos($slug, '__trashed') !== false || preg_match('/-(2|3|4|5|6|7|8|9|copy|duplicate)$/i', $slug)) continue;
      $seen[$slug] = true;
      $loc = rtrim(get_permalink($wp_p->ID), '/');
      echo '  <url><loc>' . esc_url($loc) . '</loc><lastmod>' . get_the_modified_date('Y-m-d', $wp_p->ID) . '</lastmod><changefreq>weekly</changefreq><priority>0.90</priority></url>' . "\n";
    }

    foreach (hashir_get_all_real_text_pages_data() as $seed_p) {
      $s = strtolower(trim($seed_p['slug'], '/'));
      if ($s !== '' && $s !== 'home' && empty($seen[$s]) && !preg_match('/-(2|3|4|5|6|7|8|9|copy|duplicate)$/i', $s)) {
        $seen[$s] = true;
        echo '  <url><loc>' . esc_url(untrailingslashit(home_url('/' . $s))) . '</loc><lastmod>' . date('Y-m-d') . '</lastmod><changefreq>weekly</changefreq><priority>0.90</priority></url>' . "\n";
      }
    }

    echo '</urlset>';
    exit;
  }
}
add_action('init', 'hashir_serve_dynamic_sitemap', -99999);

// Only inject blog posts on single post templates (Keeps homepage 100% clean of news/blog)
function hashir_inject_blog_posts_and_single_post_support() {
  if (!is_single()) {
    return;
  }
  $recent_posts = get_posts(array(
    'post_type'   => 'post',
    'post_status' => 'publish',
    'numberposts' => 10,
    'orderby'     => 'date',
    'order'       => 'DESC',
  ));
  $js_posts = array();
  foreach ($recent_posts as $rp) {
    $cats = get_the_category($rp->ID);
    $cat_name = (!empty($cats) && !is_wp_error($cats)) ? $cats[0]->name : 'Mandi Updates';
    $thumb = get_the_post_thumbnail_url($rp->ID, 'large');
    if (!$thumb) {
      $thumb = 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&q=80&w=1200';
    }
    $js_posts[] = array(
      'id'             => $rp->ID,
      'slug'           => $rp->post_name,
      'url'            => get_permalink($rp->ID),
      'title'          => get_the_title($rp->ID),
      'excerpt'        => wp_trim_words(wp_strip_all_tags($rp->post_excerpt ? $rp->post_excerpt : $rp->post_content), 26),
      'content'        => apply_filters('the_content', $rp->post_content),
      'date'           => get_the_date('M j, Y', $rp->ID),
      'category_name'  => $cat_name,
      'featured_image' => $thumb,
      'author_name'    => get_the_author_meta('display_name', $rp->post_author) ?: 'Haji Muhammad Hashir',
    );
  }
  $current_single = null;
  $curr_id = get_queried_object_id();
  foreach ($js_posts as $jp) {
    if (intval($jp['id']) === intval($curr_id)) {
      $current_single = $jp;
      break;
    }
  }
  ?>
  <script>
    window.__WP_BLOG_POSTS__ = <?php echo wp_json_encode($js_posts); ?>;
    window.__WP_CURRENT_POST__ = <?php echo wp_json_encode($current_single); ?>;
  </script>
  <?php
}
add_action('wp_head', 'hashir_inject_blog_posts_and_single_post_support', 1);

if (!function_exists('hashir_find_seed_page_by_slug')) {
  function hashir_find_seed_page_by_slug($slug) {
    $clean = trim(strtolower($slug), '/');
    if ($clean === '' || $clean === 'index.php') $clean = 'home';
    if (!function_exists('hashir_get_all_real_text_pages_data') && function_exists('get_template_directory') && file_exists(get_template_directory() . '/inc/all-pages-seed.php')) {
      require_once get_template_directory() . '/inc/all-pages-seed.php';
    }
    if (function_exists('hashir_get_all_real_text_pages_data')) {
      foreach (hashir_get_all_real_text_pages_data() as $p) {
        if (strtolower($p['slug']) === $clean) {
          return $p;
        }
      }
    }
    return null;
  }
}

// ==========================================
// 1. BULLETPROOF SINGLE META TITLE & DESCRIPTION (NO DUPLICATES)
// ==========================================

// Standard WordPress document title filter (Never duplicate <title>)
add_filter('pre_get_document_title', function($title) {
  if (is_front_page() || is_home()) {
    return 'Wholesale Rice Supplier Pakistan | Bucheki Mandi';
  }
  return $title;
}, 99999);

// Rank Math Title compatibility (if installed)
add_filter('rank_math/frontend/title', function($title) {
  if (is_front_page() || is_home()) {
    return 'Wholesale Rice Supplier Pakistan | Bucheki Mandi';
  }
  return $title;
}, 99999);

// Yoast SEO Title compatibility (if installed)
add_filter('wpseo_title', function($title) {
  if (is_front_page() || is_home()) {
    return 'Wholesale Rice Supplier Pakistan | Bucheki Mandi';
  }
  return $title;
}, 99999);

// Output single clean Meta Description (Suppressed if Yoast or Rank Math is active to prevent double output)
function hashir_theme_single_meta_description() {
  if (defined('WPSEO_VERSION') || defined('RANK_MATH_VERSION') || defined('AIOSEO_VERSION') || function_exists('seopress_init')) {
    return;
  }
  if (is_front_page() || is_home()) {
    $desc = 'Direct ex-mill wholesale rice supplier at Noor Galla Mandi Bucheki. Bulk 1121 Kainat Steam, Sella & Super Kernel Basmati with nationwide bilty delivery.';
  } elseif (is_singular('page') || is_singular('post')) {
    $custom_desc = get_post_meta(get_the_ID(), 'rank_math_description', true);
    if (!$custom_desc) {
      $custom_desc = get_the_excerpt();
    }
    $desc = $custom_desc ? wp_strip_all_tags($custom_desc) : 'Direct ex-mill wholesale rice supplier at Noor Galla Mandi Bucheki. Premium Basmati varieties dispatched nationwide.';
  } else {
    $desc = 'Direct ex-mill wholesale rice supplier at Noor Galla Mandi Bucheki. Bulk 1121 Kainat Steam, Sella & Super Kernel Basmati across Pakistan.';
  }
  if (mb_strlen($desc) > 155) {
    $desc = mb_substr($desc, 0, 152) . '...';
  }
  $canonical = is_front_page() ? home_url('/') : untrailingslashit(get_permalink());
  ?>
  <meta name="description" content="<?php echo esc_attr($desc); ?>">
  <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
  <link rel="canonical" href="<?php echo esc_url($canonical); ?>">
  <meta property="og:type" content="website">
  <meta property="og:title" content="<?php echo esc_attr(is_front_page() ? 'Wholesale Rice Supplier Pakistan | Bucheki Mandi' : wp_get_document_title()); ?>">
  <meta property="og:description" content="<?php echo esc_attr($desc); ?>">
  <meta property="og:url" content="<?php echo esc_url($canonical); ?>">
  <meta property="og:site_name" content="Hashir Rice Supplier">
  <meta property="og:image" content="<?php echo esc_url(get_template_directory_uri() . '/assets/rice_1121_steam_rice_1787578828007-KnyYTIEI.jpg'); ?>">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="<?php echo esc_attr(is_front_page() ? 'Wholesale Rice Supplier Pakistan | Bucheki Mandi' : wp_get_document_title()); ?>">
  <meta name="twitter:description" content="<?php echo esc_attr($desc); ?>">
  <meta name="theme-color" content="#064e3b">
  <?php
}
add_action('wp_head', 'hashir_theme_single_meta_description', 1);

// Rank Math Description override for Homepage
add_filter('rank_math/frontend/description', function($desc) {
  if (is_front_page() || is_home()) {
    return 'Direct ex-mill wholesale rice supplier at Noor Galla Mandi Bucheki. Bulk 1121 Kainat Steam, Sella & Super Kernel Basmati with nationwide bilty delivery.';
  }
  return $desc;
}, 99999);

// Yoast Description override for Homepage
add_filter('wpseo_metadesc', function($desc) {
  if (is_front_page() || is_home()) {
    return 'Direct ex-mill wholesale rice supplier at Noor Galla Mandi Bucheki. Bulk 1121 Kainat Steam, Sella & Super Kernel Basmati with nationwide bilty delivery.';
  }
  return $desc;
}, 99999);

// ==========================================
// 2. TODAY'S MANDI RICE RATES ADMIN EDIT SYSTEM
// ==========================================

function hashir_get_default_mandi_rates() {
  return array(
    'last_updated' => date('F j, Y') . ': Live Bucheki Floor',
    'note' => 'Rates are ex-mill Noor Galla Mandi Bucheki. Truckload freight bilty charges vary by destination city.',
    'varieties' => array(
      'kainat_steam' => array(
        'name' => '1121 Kainat Steam Basmati (Extra Long)',
        'grain_length' => '8.35mm - 8.45mm',
        'spec' => 'Max 12.0% • 100% Sortex',
        'rate_40kg' => 'Rs. 14,800 - 15,200',
        'rate_50kg' => 'Rs. 18,500 - 19,000',
        'status' => 'In Stock',
        'whatsapp_msg' => 'Inquiring today rate for 1121 Kainat Steam'
      ),
      'golden_sella' => array(
        'name' => '1121 Golden Sella Rice (Parboiled)',
        'grain_length' => '8.30mm - 8.40mm',
        'spec' => 'Max 12.5% • 100% Sortex',
        'rate_40kg' => 'Rs. 14,200 - 14,600',
        'rate_50kg' => 'Rs. 17,750 - 18,250',
        'status' => 'In Stock',
        'whatsapp_msg' => 'Inquiring today rate for 1121 Golden Sella'
      ),
      'creamy_sella' => array(
        'name' => '1121 Creamy Sella Rice (Parboiled)',
        'grain_length' => '8.30mm - 8.40mm',
        'spec' => 'Max 12.5% • Creamy Parboiled',
        'rate_40kg' => 'Rs. 14,400 - 14,800',
        'rate_50kg' => 'Rs. 18,000 - 18,500',
        'status' => 'In Stock',
        'whatsapp_msg' => 'Inquiring today rate for 1121 Creamy Sella'
      ),
      'super_kernel' => array(
        'name' => 'Super Kernel Basmati (Aged Reserve)',
        'grain_length' => '7.30mm - 7.50mm',
        'spec' => 'Max 12.0% • 100% Sortex',
        'rate_40kg' => 'Rs. 13,800 - 14,200',
        'rate_50kg' => 'Rs. 17,250 - 17,750',
        'status' => 'Aged Stock',
        'whatsapp_msg' => 'Inquiring today rate for Super Kernel Basmati'
      ),
      'basmati_1509' => array(
        'name' => '1509 Long Grain Basmati Rice',
        'grain_length' => '8.30mm - 8.40mm',
        'spec' => 'Max 12.5% • 100% Sortex',
        'rate_40kg' => 'Rs. 11,500 - 12,000',
        'rate_50kg' => 'Rs. 14,375 - 15,000',
        'status' => 'In Stock',
        'whatsapp_msg' => 'Inquiring today rate for 1509 Basmati'
      ),
      'irri6' => array(
        'name' => 'IRRI-6 Non-Basmati White Rice',
        'grain_length' => '6.00mm - 6.40mm',
        'spec' => 'Max 13.5% • Well-Milled',
        'rate_40kg' => 'Rs. 7,400 - 7,800',
        'rate_50kg' => 'Rs. 9,250 - 9,750',
        'status' => 'In Stock',
        'whatsapp_msg' => 'Inquiring today rate for IRRI-6'
      ),
      'broken_b1' => array(
        'name' => 'Broken Basmati Rice Totta (B1 Sortex)',
        'grain_length' => '4.50mm - 5.50mm',
        'spec' => 'Clean Sortex • Zero Dust',
        'rate_40kg' => 'Rs. 7,800 - 8,400',
        'rate_50kg' => 'Rs. 9,750 - 10,500',
        'status' => 'In Stock',
        'whatsapp_msg' => 'Inquiring today rate for Broken Rice Totta B1'
      ),
    )
  );
}

function hashir_get_mandi_rates() {
  $saved = get_option('hashir_mandi_rates');
  $default = hashir_get_default_mandi_rates();
  if (!is_array($saved) || empty($saved['varieties'])) {
    return $default;
  }
  return wp_parse_args($saved, $default);
}

// Add Admin Menu Page: Mandi Rice Rates
add_action('admin_menu', function() {
  add_menu_page(
    "Today's Mandi Rice Rates",
    'Mandi Rice Rates',
    'manage_options',
    'mandi-rates',
    'hashir_render_mandi_rates_admin_page',
    'dashicons-chart-line',
    25
  );
});

// Admin Form Submission Handler
add_action('admin_post_hashir_save_mandi_rates', function() {
  if (!current_user_can('manage_options')) {
    wp_die('Unauthorized');
  }
  check_admin_referer('hashir_save_rates_action', 'hashir_rates_nonce');

  $current = hashir_get_mandi_rates();
  $rates_post = isset($_POST['mandi_rates']) ? (array)$_POST['mandi_rates'] : array();

  if (isset($rates_post['last_updated'])) {
    $current['last_updated'] = sanitize_text_field($rates_post['last_updated']);
  }
  if (isset($rates_post['note'])) {
    $current['note'] = sanitize_text_field($rates_post['note']);
  }

  if (isset($rates_post['varieties']) && is_array($rates_post['varieties'])) {
    foreach ($rates_post['varieties'] as $key => $vals) {
      if (isset($current['varieties'][$key])) {
        if (isset($vals['rate_40kg'])) $current['varieties'][$key]['rate_40kg'] = sanitize_text_field($vals['rate_40kg']);
        if (isset($vals['rate_50kg'])) $current['varieties'][$key]['rate_50kg'] = sanitize_text_field($vals['rate_50kg']);
        if (isset($vals['grain_length'])) $current['varieties'][$key]['grain_length'] = sanitize_text_field($vals['grain_length']);
        if (isset($vals['spec'])) $current['varieties'][$key]['spec'] = sanitize_text_field($vals['spec']);
        if (isset($vals['status'])) $current['varieties'][$key]['status'] = sanitize_text_field($vals['status']);
      }
    }
  }

  update_option('hashir_mandi_rates', $current);
  wp_redirect(admin_url('admin.php?page=mandi-rates&updated=1'));
  exit;
});

// Render the WordPress Admin Page
function hashir_render_mandi_rates_admin_page() {
  $data = hashir_get_mandi_rates();
  $updated = isset($_GET['updated']) && $_GET['updated'] == '1';
  ?>
  <div class="wrap" style="max-width:1150px;">
    <h1 style="display:flex;align-items:center;gap:10px;font-weight:700;color:#064e3b;">
      <span class="dashicons dashicons-chart-line" style="font-size:32px;width:32px;height:32px;color:#047857;"></span>
      Today&#39;s Mandi Rice Rates &amp; Ex-Mill Spot Quotations (Admin Editor)
    </h1>
    <p style="color:#4b5563;font-size:14px;margin-bottom:20px;">
      Edit spot prices and specifications for all rice varieties. Changes update live across the homepage table and quote calculations instantly!
    </p>

    <?php if ($updated): ?>
      <div class="notice notice-success is-dismissible" style="border-left-color:#059669;padding:12px 16px;">
        <p style="margin:0;font-size:14px;font-weight:600;color:#065f46;">
          ✓ Mandi rates successfully updated! Live homepage rates table has been refreshed.
        </p>
      </div>
    <?php endif; ?>

    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
      <input type="hidden" name="action" value="hashir_save_mandi_rates">
      <?php wp_nonce_field('hashir_save_rates_action', 'hashir_rates_nonce'); ?>

      <div style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:20px;margin-bottom:24px;box-shadow:0 1px 3px rgba(0,0,0,0.05);">
        <h2 style="font-size:16px;font-weight:700;margin-top:0;color:#111827;border-bottom:1px solid #f3f4f6;padding-bottom:10px;">
          Floor Bulletin Settings
        </h2>
        <div style="display:grid;grid-template-columns:1fr 2fr;gap:20px;">
          <div>
            <label style="display:block;font-weight:600;margin-bottom:6px;font-size:13px;">Date / Bulletin Timestamp:</label>
            <input type="text" name="mandi_rates[last_updated]" value="<?php echo esc_attr($data['last_updated']); ?>" style="width:100%;padding:8px 12px;border:1px solid #d1d5db;border-radius:6px;font-size:13px;">
            <p style="color:#6b7280;font-size:12px;margin:4px 0 0 0;">e.g., Today (Live Bucheki Floor)</p>
          </div>
          <div>
            <label style="display:block;font-weight:600;margin-bottom:6px;font-size:13px;">Mandi Terms &amp; Disclaimer Note:</label>
            <input type="text" name="mandi_rates[note]" value="<?php echo esc_attr($data['note']); ?>" style="width:100%;padding:8px 12px;border:1px solid #d1d5db;border-radius:6px;font-size:13px;">
            <p style="color:#6b7280;font-size:12px;margin:4px 0 0 0;">Displayed directly under the rates table on homepage</p>
          </div>
        </div>
      </div>

      <div style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:20px;margin-bottom:24px;box-shadow:0 1px 3px rgba(0,0,0,0.05);">
        <h2 style="font-size:16px;font-weight:700;margin-top:0;color:#111827;border-bottom:1px solid #f3f4f6;padding-bottom:10px;">
          Rice Varieties Spot Price Matrix
        </h2>

        <table style="width:100%;border-collapse:collapse;font-size:13px;">
          <thead>
            <tr style="background:#f9fafb;border-bottom:2px solid #e5e7eb;text-align:left;">
              <th style="padding:10px 12px;color:#374151;">Rice Variety</th>
              <th style="padding:10px 12px;color:#374151;">Rate / 40kg Maund</th>
              <th style="padding:10px 12px;color:#374151;">Rate / 50kg Bag</th>
              <th style="padding:10px 12px;color:#374151;">Grain Length</th>
              <th style="padding:10px 12px;color:#374151;">Moisture / Sortex Spec</th>
              <th style="padding:10px 12px;color:#374151;">Availability</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($data['varieties'] as $key => $v): ?>
              <tr style="border-bottom:1px solid #f3f4f6;">
                <td style="padding:12px;font-weight:600;color:#064e3b;">
                  <?php echo esc_html($v['name']); ?>
                </td>
                <td style="padding:12px;">
                  <input type="text" name="mandi_rates[varieties][<?php echo esc_attr($key); ?>][rate_40kg]" value="<?php echo esc_attr($v['rate_40kg']); ?>" style="width:100%;padding:6px 10px;border:1px solid #d1d5db;border-radius:6px;font-weight:600;color:#047857;">
                </td>
                <td style="padding:12px;">
                  <input type="text" name="mandi_rates[varieties][<?php echo esc_attr($key); ?>][rate_50kg]" value="<?php echo esc_attr($v['rate_50kg']); ?>" style="width:100%;padding:6px 10px;border:1px solid #d1d5db;border-radius:6px;font-weight:600;">
                </td>
                <td style="padding:12px;">
                  <input type="text" name="mandi_rates[varieties][<?php echo esc_attr($key); ?>][grain_length]" value="<?php echo esc_attr($v['grain_length']); ?>" style="width:100%;padding:6px 10px;border:1px solid #d1d5db;border-radius:6px;">
                </td>
                <td style="padding:12px;">
                  <input type="text" name="mandi_rates[varieties][<?php echo esc_attr($key); ?>][spec]" value="<?php echo esc_attr($v['spec']); ?>" style="width:100%;padding:6px 10px;border:1px solid #d1d5db;border-radius:6px;">
                </td>
                <td style="padding:12px;">
                  <input type="text" name="mandi_rates[varieties][<?php echo esc_attr($key); ?>][status]" value="<?php echo esc_attr($v['status']); ?>" style="width:100%;padding:6px 10px;border:1px solid #d1d5db;border-radius:6px;">
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <div style="display:flex;align-items:center;gap:12px;">
        <button type="submit" class="button button-primary" style="background:#047857;border-color:#065f46;padding:8px 24px;height:auto;font-size:14px;font-weight:700;">
          Save Today&#39;s Mandi Rates
        </button>
        <a href="<?php echo esc_url(home_url('/')); ?>" target="_blank" class="button" style="padding:8px 18px;height:auto;font-size:14px;">
          View Live Homepage
        </a>
      </div>
    </form>
  </div>
  <?php
}
