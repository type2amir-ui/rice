<?php
/**
 * 404 Template - Hashir Rice Supplier
 */
if (!defined('ABSPATH')) { exit; }
get_header();
?>
<main class="py-20 bg-stone-50 text-center">
  <div class="max-w-md mx-auto px-4">
    <span class="text-5xl font-extrabold text-emerald-900">404</span>
    <h1 class="font-serif text-2xl font-bold text-neutral-900 mt-4 mb-2">Page Not Found</h1>
    <p class="text-sm text-neutral-600 mb-8">The requested page or mandi document does not exist. Explore our primary wholesale rice directories below:</p>
    <div class="flex flex-col sm:flex-row justify-center gap-3">
      <a href="<?php echo esc_url(home_url('/')); ?>" class="bg-emerald-800 text-amber-300 font-bold py-2.5 px-5 rounded-lg text-xs">Return Home</a>
      <a href="<?php echo esc_url(home_url('/varieties')); ?>" class="bg-stone-200 text-neutral-800 font-bold py-2.5 px-5 rounded-lg text-xs">Rice Varieties</a>
      <a href="<?php echo esc_url(home_url('/contact')); ?>" class="bg-stone-200 text-neutral-800 font-bold py-2.5 px-5 rounded-lg text-xs">Contact Desk</a>
    </div>
  </div>
</main>
<?php
get_footer();
