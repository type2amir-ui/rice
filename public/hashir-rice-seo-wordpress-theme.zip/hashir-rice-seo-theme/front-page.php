<?php
/**
 * Front Page Template - Hashir Rice Supplier
 */
if (!defined('ABSPATH')) { exit; }
get_header();

$mandi_data = function_exists('hashir_get_mandi_rates') ? hashir_get_mandi_rates() : null;
if (!$mandi_data && function_exists('hashir_get_default_mandi_rates')) {
  $mandi_data = hashir_get_default_mandi_rates();
}
$theme_uri = get_template_directory_uri();
?>
<main id="main-content">
  <!-- 1. Hero Section: Exact Google Studio Match with Hashir Rice Bags & Semantic Keywords -->
  <section class="relative overflow-hidden bg-gradient-to-b from-emerald-50/70 via-white to-neutral-50/50 pt-10 pb-16 border-b border-neutral-200/80">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
        <!-- Left Hero Column -->
        <div class="lg:col-span-7 space-y-5">
          <div class="inline-flex flex-wrap items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-900/10 border border-emerald-800/20 text-emerald-950 text-xs font-semibold tracking-wide">
            <span class="flex h-2 w-2 rounded-full bg-emerald-600 animate-ping"></span>
            <span>🌾 Hashir Rice • Noor Galla Mandi Bucheki • Sourcing &amp; Brokerage Desk</span>
          </div>

          <h1 class="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-neutral-950 leading-[1.15]">
            Rice Supplier, Wholesale Rice Broker &amp; Bulk Rice Supplier in <span class="text-emerald-900 underline decoration-amber-400 decoration-4 underline-offset-4">Pakistan</span>
          </h1>

          <p class="text-base sm:text-lg text-neutral-700 leading-relaxed font-normal">
            <strong>Haji Muhammad Hashir</strong> is your trusted <strong>Rice Supplier</strong>, licensed <strong>Rice Broker</strong>, and premier <strong>Rice Wholesale Dealer</strong> operating from Noor Galla Mandi, Bucheki (Punjab). As top <strong>Wholesale Rice Suppliers</strong> and nationwide <strong>Bulk Rice Supplier</strong>, we supply 50kg and 25kg woven bags of <strong>Hashir Rice</strong> (1121 Kainat Steam &amp; Sella, Super Kernel Basmati, 1509, PK-386, and IRRI-6) with transparent mandi commission and express bilty logistics across 60+ cities in Pakistan. In the future, we are expanding into centralized commodity <strong>Rice Trading</strong>.
          </p>

          <div class="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1 text-xs font-medium text-neutral-800">
            <div class="flex items-center gap-2 p-2 rounded-lg bg-white border border-neutral-200/90 shadow-2xs">
              <span class="text-emerald-700 font-bold">✓</span>
              <span>Wholesale Rice Suppliers</span>
            </div>
            <div class="flex items-center gap-2 p-2 rounded-lg bg-white border border-neutral-200/90 shadow-2xs">
              <span class="text-emerald-700 font-bold">✓</span>
              <span>Wholesale Rice Broker</span>
            </div>
            <div class="flex items-center gap-2 p-2 rounded-lg bg-white border border-neutral-200/90 shadow-2xs">
              <span class="text-emerald-700 font-bold">✓</span>
              <span>Bulk Rice Supplier</span>
            </div>
            <div class="flex items-center gap-2 p-2 rounded-lg bg-white border border-neutral-200/90 shadow-2xs">
              <span class="text-emerald-700 font-bold">✓</span>
              <span>Future Rice Trading Desk</span>
            </div>
          </div>

          <div class="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2">
            <a href="https://wa.me/923338990883?text=Assalam-o-Alaikum%20Hashir%20Rice,%20I%20want%20to%20inquire%20about%20today's%20wholesale%20rates" target="_blank" rel="noopener noreferrer" class="px-6 py-3.5 rounded-xl bg-emerald-900 hover:bg-emerald-950 text-white font-semibold text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2">
              <span>💬</span> Inquire Spot Price on WhatsApp
            </a>
            <a href="<?php echo esc_url(home_url('/sample-request')); ?>" class="px-6 py-3.5 rounded-xl bg-white hover:bg-neutral-50 text-neutral-900 border border-neutral-300 font-semibold text-sm transition-all flex items-center justify-center gap-2 shadow-2xs">
              <span>Order Physical Sample</span>
              <span>&rarr;</span>
            </a>
            <a href="tel:+923338990883" class="px-4 py-3.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-900 font-semibold text-sm border border-emerald-300 transition-all flex items-center justify-center gap-2">
              <span>📞</span> 0333 8990883 / 0300 2861297
            </a>
          </div>

          <div class="pt-1 flex items-center gap-2 text-xs text-neutral-600">
            <span class="text-emerald-800">📍</span>
            <span><strong>Noor Galla Mandi, Bucheki (Punjab):</strong> Direct Rice Supplier &amp; Rice Wholesale Dealer with daily Bilty to Lahore, Karachi, Rawalpindi, Islamabad, Faisalabad, Peshawar, Quetta &amp; 60+ Cities</span>
          </div>
        </div>

        <!-- Right Hero Column: Hashir Rice Bags Showcase -->
        <div class="lg:col-span-5 relative">
          <div class="relative mx-auto max-w-md lg:max-w-none">
            <div class="rounded-2xl overflow-hidden shadow-2xl border border-neutral-200/90 bg-white group">
              <div class="relative h-72 sm:h-80 overflow-hidden bg-stone-100">
                <img
                  src="<?php echo esc_url($theme_uri . '/assets/hashir_rice_bags.jpg'); ?>"
                  alt="Hashir Rice 50kg and 25kg Wholesale Rice Bags Packaging - Noor Galla Mandi Bucheki"
                  class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  onerror="this.src='<?php echo esc_url(home_url('/hashir_rice_bags.jpg')); ?>'"
                  loading="eager"
                />
                <div class="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent"></div>
                
                <div class="absolute top-4 left-4 bg-white/95 backdrop-blur-md px-3 py-1.5 rounded-lg shadow-md border border-neutral-200 text-xs">
                  <span class="font-bold text-emerald-950 block">Hashir Rice Bags</span>
                  <span class="text-[11px] text-neutral-600">50 KG &amp; 25 KG Woven Packaging</span>
                </div>

                <div class="absolute top-4 right-4 bg-emerald-900/90 text-amber-300 text-xs px-2.5 py-1 rounded-md font-semibold">
                  Lab Verified Lot
                </div>

                <div class="absolute bottom-4 left-4 right-4 text-white">
                  <div class="text-xs font-semibold uppercase tracking-wider text-amber-300 mb-1">
                    Direct Mill &amp; Mandi Brokerage Desk
                  </div>
                  <div class="text-base font-bold font-serif leading-tight">
                    Hashir Rice Supreme Basmati &amp; Kainat
                  </div>
                  <p class="text-[11px] text-emerald-100 mt-0.5">Double-stitched woven bags • Moisture &lt;12.0% • 100% Buhler Sortex</p>
                </div>
              </div>

              <div class="p-4 bg-neutral-50 grid grid-cols-3 gap-2.5 border-t border-neutral-200 text-center">
                <div class="p-2 bg-white rounded-lg border border-neutral-200">
                  <div class="text-[10px] text-neutral-500 uppercase font-semibold">MOQ</div>
                  <div class="text-sm font-bold text-neutral-900">100 Bags</div>
                  <div class="text-[10px] text-emerald-700 font-medium">5 Metric Tons</div>
                </div>
                <div class="p-2 bg-white rounded-lg border border-neutral-200">
                  <div class="text-[10px] text-neutral-500 uppercase font-semibold">Packaging</div>
                  <div class="text-sm font-bold text-neutral-900">50kg / 25kg</div>
                  <div class="text-[10px] text-emerald-700 font-medium">Hashir Rice Bags</div>
                </div>
                <div class="p-2 bg-white rounded-lg border border-neutral-200">
                  <div class="text-[10px] text-neutral-500 uppercase font-semibold">Dispatch</div>
                  <div class="text-sm font-bold text-neutral-900">24–48 Hrs</div>
                  <div class="text-[10px] text-emerald-700 font-medium">Nationwide Bilty</div>
                </div>
              </div>

              <div class="p-3 bg-emerald-50 text-neutral-900 border-t border-emerald-200 flex items-center justify-between text-xs">
                <div>
                  <span class="font-semibold text-neutral-950 block">Need testing samples before purchase?</span>
                  <span class="text-emerald-900 text-[11px] font-medium">We courier sealed Hashir Rice cooking test lots</span>
                </div>
                <a href="<?php echo esc_url(home_url('/sample-request')); ?>" class="px-3 py-1.5 bg-emerald-900 hover:bg-emerald-950 text-white font-bold rounded-lg transition-colors shrink-0 shadow-2xs">
                  Request Sample
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- 2. Today's Mandi Rice Rates - COMPACT WITH LIGHT BACKGROUND (Admin Editable in WP) -->
  <section id="rice-exchange" class="py-8 sm:py-10 bg-stone-50 text-neutral-900 border-b border-stone-200">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
      <div class="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-4 border-b border-stone-200">
        <div class="space-y-2 max-w-3xl">
          <div class="flex flex-wrap items-center gap-2">
            <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 text-xs font-bold uppercase tracking-wider border border-emerald-200">
              <span>🏛️</span>
              <span>Noor Galla Mandi Bucheki • Ex-Mill Trading Desk</span>
            </div>
            <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white text-stone-700 text-xs font-semibold border border-stone-200 shadow-2xs">
              <span>📅</span>
              <span>Rates Effective: <strong class="text-neutral-950"><?php echo esc_html(!empty($mandi_data['last_updated']) ? $mandi_data['last_updated'] : date('F j, Y')); ?></strong></span>
            </div>
          </div>

          <h2 class="font-serif text-2xl sm:text-3xl font-bold tracking-tight text-neutral-950 leading-tight">
            Today&#39;s Mandi Rice Rates &amp; Ex-Mill Spot Quotations
          </h2>
          <p class="text-xs sm:text-sm text-stone-600 leading-relaxed">
            Transparent daily wholesale spot quotations direct from Noor Galla Mandi Bucheki (Punjab). Dynamic ex-mill quotations updated by Mandi Desk admin with 0.5%–1% brokerage.
          </p>
        </div>

        <div class="flex flex-wrap items-center gap-2.5 shrink-0">
          <?php if (current_user_can('manage_options')) : ?>
            <a href="<?php echo esc_url(admin_url('admin.php?page=mandi-rates')); ?>" class="px-3 py-2 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-amber-300 font-bold text-xs shadow-2xs transition flex items-center gap-1.5">
              <span>✏️</span>
              <span>Edit Rates in WP Admin</span>
            </a>
          <?php endif; ?>
          <a href="https://wa.me/923338990883?text=Assalam-o-Alaikum%20Hashir%20Rice,%20please%20share%20today's%20rate%20sheet" target="_blank" rel="noopener noreferrer" class="px-3.5 py-2 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-1.5">
            <span>💬</span>
            <span>Full Sheet on WhatsApp</span>
          </a>
        </div>
      </div>

      <!-- Category Filter Tabs -->
      <div class="flex flex-wrap items-center justify-between gap-3" id="mandi-rate-tabs">
        <div class="flex flex-wrap items-center gap-1.5">
          <button type="button" data-filter="all" class="rate-tab-btn px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer bg-emerald-900 text-amber-300 shadow-xs border border-emerald-800">
            All 10 Mandi Varieties
          </button>
          <button type="button" data-filter="basmati" class="rate-tab-btn px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer bg-white text-stone-700 hover:bg-stone-100 border border-stone-200">
            1121 &amp; Super Basmati
          </button>
          <button type="button" data-filter="broken" class="rate-tab-btn px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer bg-white text-stone-700 hover:bg-stone-100 border border-stone-200">
            B1 / B2 / B3 Broken Rice
          </button>
          <button type="button" data-filter="commercial" class="rate-tab-btn px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer bg-white text-stone-700 hover:bg-stone-100 border border-stone-200">
            Commercial IRRI &amp; PK-386
          </button>
        </div>
        <div class="text-[11px] text-stone-500 flex items-center gap-1.5">
          <span class="w-2 h-2 rounded-full bg-emerald-600 animate-pulse"></span>
          <span>Ex-Mill Noor Galla Mandi Bucheki • Verified Bilty</span>
        </div>
      </div>

      <!-- Compact Light Rates Table / Grid -->
      <div class="overflow-x-auto rounded-xl border border-stone-200 bg-white shadow-2xs">
        <table class="w-full text-left text-sm" id="mandi-rates-table">
          <thead class="bg-stone-100/80 text-stone-700 uppercase font-semibold text-xs border-b border-stone-200">
            <tr>
              <th class="py-3 px-4">Rice Variety &amp; Grade</th>
              <th class="py-3 px-4">Avg Grain Length</th>
              <th class="py-3 px-4">Moisture / Sortex</th>
              <th class="py-3 px-4">Rate / 40kg Maund</th>
              <th class="py-3 px-4">Rate / 50kg Bag</th>
              <th class="py-3 px-4 text-right">Inquire Spot</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-stone-200 text-stone-800">
            <?php if (!empty($mandi_data['varieties'])) : ?>
              <?php foreach ($mandi_data['varieties'] as $key => $v) : 
                $cat = 'commercial';
                $lowerName = strtolower($v['name']);
                if (strpos($lowerName, 'basmati') !== false || strpos($lowerName, '1121') !== false || strpos($lowerName, 'kainat') !== false) {
                  $cat = 'basmati';
                } elseif (strpos($lowerName, 'broken') !== false || strpos($lowerName, 'tota') !== false) {
                  $cat = 'broken';
                }
              ?>
                <tr class="rate-row hover:bg-stone-50 transition" data-category="<?php echo esc_attr($cat); ?>">
                  <td class="py-3.5 px-4 font-bold text-emerald-950">
                    <?php echo esc_html($v['name']); ?>
                    <?php if (!empty($v['status'])) : ?>
                      <span class="ml-2 text-[10px] bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded font-bold uppercase"><?php echo esc_html($v['status']); ?></span>
                    <?php endif; ?>
                  </td>
                  <td class="py-3.5 px-4 text-xs"><?php echo esc_html($v['grain_length']); ?></td>
                  <td class="py-3.5 px-4 text-xs text-stone-600"><?php echo esc_html($v['spec']); ?></td>
                  <td class="py-3.5 px-4 font-semibold text-emerald-900"><?php echo esc_html($v['rate_40kg']); ?></td>
                  <td class="py-3.5 px-4 font-bold text-emerald-950"><?php echo esc_html($v['rate_50kg']); ?></td>
                  <td class="py-3.5 px-4 text-right">
                    <a href="<?php echo esc_url('https://wa.me/923338990883?text=' . urlencode(!empty($v['whatsapp_msg']) ? $v['whatsapp_msg'] : 'Inquiring today rate for ' . $v['name'])); ?>" target="_blank" rel="noopener noreferrer" class="text-xs bg-emerald-900 hover:bg-emerald-950 text-amber-300 font-bold px-3 py-1.5 rounded-lg inline-block transition shadow-2xs">
                      Lock on WhatsApp
                    </a>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <div class="p-3 bg-emerald-50/80 border border-emerald-200 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-stone-700">
        <p class="leading-relaxed">
          * <strong>Transparent Mandi Sourcing:</strong> Direct ex-mill spot rates Noor Galla Mandi Bucheki. Truckload freight bilty charges vary by destination city (Rs. 150 – Rs. 400 per 50kg bag).
        </p>
        <span class="font-bold text-emerald-950 shrink-0">Desk: 0333 8990883 / 0300 2861297</span>
      </div>
    </div>
  </section>

  <!-- 3. 6 Products Catalog Grid -->
  <section class="py-14 bg-white border-b border-stone-200">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
        <div>
          <span class="text-xs font-bold text-emerald-800 uppercase tracking-widest">Our Catalog</span>
          <h2 class="font-serif text-2xl sm:text-3xl font-bold text-neutral-900 mt-2">Wholesale Rice Varieties</h2>
          <p class="text-neutral-600 text-sm mt-1">Directly sourced, moisture-tested, and double-bagged in Hashir Rice 50kg &amp; 25kg sacks.</p>
        </div>
        <a href="<?php echo esc_url(home_url('/varieties')); ?>" class="text-emerald-800 hover:text-emerald-900 font-bold text-sm flex items-center gap-1">
          View All Varieties &rarr;
        </a>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div class="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-2xs hover:shadow-md transition">
          <div class="h-48 bg-stone-100 relative overflow-hidden">
            <img src="<?php echo esc_url($theme_uri . '/assets/rice_1121_steam_rice_1787578828007-KnyYTIEI.jpg'); ?>" alt="1121 Kainat Steam Basmati Rice" class="w-full h-full object-cover" onerror="this.src='https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=800&q=80'">
            <span class="absolute top-3 right-3 bg-emerald-900 text-amber-300 text-xs font-bold px-2.5 py-1 rounded-md">8.40mm+ Length</span>
          </div>
          <div class="p-5">
            <h3 class="font-serif font-bold text-lg text-emerald-950 mb-1.5">1121 Kainat Steam Basmati</h3>
            <p class="text-neutral-600 text-xs mb-3">Supreme aromatic long grain. Non-sticky, elongates up to 22mm+ during dum cooking. Top pick for Karachi and Lahore biryani centers.</p>
            <div class="bg-stone-50 rounded-lg p-3 text-xs space-y-1.5 mb-4 text-neutral-700">
              <div class="flex justify-between"><span>Moisture:</span><strong>Max 12.0%</strong></div>
              <div class="flex justify-between"><span>Cooked Length:</span><strong>20mm - 24mm</strong></div>
              <div class="flex justify-between"><span>Purity:</span><strong>100% Sortex Clean</strong></div>
            </div>
            <div class="flex items-center gap-2">
              <a href="https://wa.me/923338990883?text=Booking%20inquiry%20for%201121%20Kainat%20Steam" target="_blank" class="flex-1 bg-emerald-800 hover:bg-emerald-900 text-amber-300 font-bold py-2 px-3 rounded-lg text-center text-xs">WhatsApp Quote</a>
              <a href="<?php echo esc_url(home_url('/sample-request')); ?>" class="bg-stone-100 hover:bg-stone-200 text-neutral-800 font-bold py-2 px-3 rounded-lg text-xs border border-stone-300">Sample</a>
            </div>
          </div>
        </div>

        <div class="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-2xs hover:shadow-md transition">
          <div class="h-48 bg-stone-100 relative overflow-hidden">
            <img src="<?php echo esc_url($theme_uri . '/assets/rice_1121_sella_rice_1787578848627-dt-PGo1h.jpg'); ?>" alt="1121 Golden Sella Rice" class="w-full h-full object-cover" onerror="this.src='https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=800&q=80'">
            <span class="absolute top-3 right-3 bg-emerald-900 text-amber-300 text-xs font-bold px-2.5 py-1 rounded-md">Golden Parboiled</span>
          </div>
          <div class="p-5">
            <h3 class="font-serif font-bold text-lg text-emerald-950 mb-1.5">1121 Golden &amp; Creamy Sella</h3>
            <p class="text-neutral-600 text-xs mb-3">Hard-grain parboiled rice. Withstands heavy catering cauldrons, commercial steam warming, and high-volume catering without breaking.</p>
            <div class="bg-stone-50 rounded-lg p-3 text-xs space-y-1.5 mb-4 text-neutral-700">
              <div class="flex justify-between"><span>Moisture:</span><strong>Max 12.5%</strong></div>
              <div class="flex justify-between"><span>Cooked Length:</span><strong>19mm - 22mm</strong></div>
              <div class="flex justify-between"><span>Breakage:</span><strong>Under 1.0%</strong></div>
            </div>
            <div class="flex items-center gap-2">
              <a href="https://wa.me/923338990883?text=Booking%20inquiry%20for%201121%20Sella" target="_blank" class="flex-1 bg-emerald-800 hover:bg-emerald-900 text-amber-300 font-bold py-2 px-3 rounded-lg text-center text-xs">WhatsApp Quote</a>
              <a href="<?php echo esc_url(home_url('/sample-request')); ?>" class="bg-stone-100 hover:bg-stone-200 text-neutral-800 font-bold py-2 px-3 rounded-lg text-xs border border-stone-300">Sample</a>
            </div>
          </div>
        </div>

        <div class="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-2xs hover:shadow-md transition">
          <div class="h-48 bg-stone-100 relative overflow-hidden">
            <img src="<?php echo esc_url($theme_uri . '/assets/rice_super_kernel_basmati_1787578898315-BjOV5UXv.jpg'); ?>" alt="Super Kernel Basmati Rice" class="w-full h-full object-cover" onerror="this.src='https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=800&q=80'">
            <span class="absolute top-3 right-3 bg-emerald-900 text-amber-300 text-xs font-bold px-2.5 py-1 rounded-md">Aged 18+ Months</span>
          </div>
          <div class="p-5">
            <h3 class="font-serif font-bold text-lg text-emerald-950 mb-1.5">Super Kernel Basmati (Old Reserve)</h3>
            <p class="text-neutral-600 text-xs mb-3">Traditional Pakistani aromatic basmati with classic vintage flavor. Ideal for high-end dining, authentic mutton pulao, and overseas export.</p>
            <div class="bg-stone-50 rounded-lg p-3 text-xs space-y-1.5 mb-4 text-neutral-700">
              <div class="flex justify-between"><span>Moisture:</span><strong>Max 12.0%</strong></div>
              <div class="flex justify-between"><span>Aging:</span><strong>18 to 24 Months</strong></div>
              <div class="flex justify-between"><span>Aroma:</span><strong>Natural Basmati</strong></div>
            </div>
            <div class="flex items-center gap-2">
              <a href="https://wa.me/923338990883?text=Booking%20inquiry%20for%20Super%20Kernel%20Basmati" target="_blank" class="flex-1 bg-emerald-800 hover:bg-emerald-900 text-amber-300 font-bold py-2 px-3 rounded-lg text-center text-xs">WhatsApp Quote</a>
              <a href="<?php echo esc_url(home_url('/sample-request')); ?>" class="bg-stone-100 hover:bg-stone-200 text-neutral-800 font-bold py-2 px-3 rounded-lg text-xs border border-stone-300">Sample</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- 4. 7-Stage Mandi Quality Workflow -->
  <section class="py-14 bg-stone-50 border-b border-stone-200">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="text-center max-w-2xl mx-auto mb-10">
        <span class="text-xs font-bold text-emerald-800 uppercase tracking-widest">Quality Assurance</span>
        <h2 class="font-serif text-2xl sm:text-3xl font-bold text-neutral-900 mt-2">7-Stage Mandi Inspection Workflow</h2>
        <p class="text-neutral-600 text-sm mt-2">Every bag is tested before truck loading. We verify grain length, moisture, and weight so you never face kitchen rejection.</p>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        <div class="p-5 bg-white rounded-xl border border-stone-200 shadow-2xs">
          <div class="w-9 h-9 rounded-lg bg-emerald-800 text-amber-300 flex items-center justify-center font-bold text-sm mb-3">1</div>
          <h3 class="font-bold text-neutral-900 mb-1 text-sm">Paddy Lot Audit</h3>
          <p class="text-neutral-600 text-xs leading-relaxed">Direct inspection of paddy harvest at Bucheki and Nankana partner shellers. Rejection of unaged or mixed hybrid crop.</p>
        </div>
        <div class="p-5 bg-white rounded-xl border border-stone-200 shadow-2xs">
          <div class="w-9 h-9 rounded-lg bg-emerald-800 text-amber-300 flex items-center justify-center font-bold text-sm mb-3">2</div>
          <h3 class="font-bold text-neutral-900 mb-1 text-sm">Moisture Meter Test</h3>
          <p class="text-neutral-600 text-xs leading-relaxed">Digital moisture calibration capped at 12.0%. Prevents storage shrinkage, fungus, and weight loss during transportation.</p>
        </div>
        <div class="p-5 bg-white rounded-xl border border-stone-200 shadow-2xs">
          <div class="w-9 h-9 rounded-lg bg-emerald-800 text-amber-300 flex items-center justify-center font-bold text-sm mb-3">3</div>
          <h3 class="font-bold text-neutral-900 mb-1 text-sm">Caliper Grain Check</h3>
          <p class="text-neutral-600 text-xs leading-relaxed">Vernier caliper measurement verifying raw grain averages 8.35mm to 8.50mm before bagging.</p>
        </div>
        <div class="p-5 bg-white rounded-xl border border-stone-200 shadow-2xs">
          <div class="w-9 h-9 rounded-lg bg-emerald-800 text-amber-300 flex items-center justify-center font-bold text-sm mb-3">4</div>
          <h3 class="font-bold text-neutral-900 mb-1 text-sm">Buhler Sortex Cleaning</h3>
          <p class="text-neutral-600 text-xs leading-relaxed">Multi-camera optical color sorting removing chalky, discolored, and broken kernels for visual purity.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- 5. About Founder & Sourcing Heritage -->
  <section class="py-14 bg-white border-b border-stone-200">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
        <div>
          <span class="text-xs font-bold text-emerald-800 uppercase tracking-widest">About Haji Muhammad Hashir</span>
          <h2 class="font-serif text-2xl sm:text-3xl font-bold text-neutral-900 mt-2 mb-4">
            Noor Galla Mandi Heritage &amp; Transparent Rice Brokerage
          </h2>
          <p class="text-neutral-700 text-sm leading-relaxed mb-3">
            Operating from the heart of Pakistan's basmati paddy corridor at <strong>Noor Galla Mandi, Bucheki (Nankana Sahib, Punjab)</strong>, Haji Muhammad Hashir provides direct commercial sourcing without middleman markup.
          </p>
          <p class="text-neutral-700 text-sm leading-relaxed mb-5">
            We operate across four major commercial pillars: certified <strong>Rice Supplier</strong>, licensed <strong>Rice Broker</strong> (transparent 0.5%–1% commission), nationwide <strong>Bulk Rice Supplier</strong>, and future electronic <strong>Rice Trading</strong> desk.
          </p>
          <div class="grid grid-cols-2 gap-3 text-xs">
            <div class="p-3 bg-stone-50 rounded-lg border border-stone-200">
              <strong class="block text-emerald-900 text-sm mb-1">0% Hidden Spreads</strong>
              <span class="text-neutral-600">Pure mandi floor rates with open weighbridge slips</span>
            </div>
            <div class="p-3 bg-stone-50 rounded-lg border border-stone-200">
              <strong class="block text-emerald-900 text-sm mb-1">Nationwide Bilty</strong>
              <span class="text-neutral-600">Daily Mazda and truckload bilty to 60+ cities</span>
            </div>
          </div>
        </div>
        <div class="bg-stone-50 p-6 sm:p-8 rounded-2xl border border-stone-200 shadow-2xs">
          <h3 class="font-serif font-bold text-xl text-neutral-900 mb-3">Direct Mandi Spot Inquiry</h3>
          <form action="<?php echo esc_url(home_url('/contact')); ?>" method="post" class="space-y-3.5">
            <div>
              <label class="block text-xs font-semibold text-neutral-700 mb-1">Your Name / Business Name</label>
              <input type="text" name="buyer_name" required placeholder="e.g. Haji Tariq Mehmood / Royal Catering" class="w-full text-sm px-3.5 py-2.5 rounded-lg border border-stone-300 focus:ring-2 focus:ring-emerald-800 focus:outline-none bg-white">
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label class="block text-xs font-semibold text-neutral-700 mb-1">Mobile / WhatsApp</label>
                <input type="tel" name="buyer_phone" required placeholder="0300 1234567" class="w-full text-sm px-3.5 py-2.5 rounded-lg border border-stone-300 focus:ring-2 focus:ring-emerald-800 focus:outline-none bg-white">
              </div>
              <div>
                <label class="block text-xs font-semibold text-neutral-700 mb-1">Destination City</label>
                <input type="text" name="destination_city" required placeholder="Lahore / Karachi / Rawalpindi" class="w-full text-sm px-3.5 py-2.5 rounded-lg border border-stone-300 focus:ring-2 focus:ring-emerald-800 focus:outline-none bg-white">
              </div>
            </div>
            <div>
              <label class="block text-xs font-semibold text-neutral-700 mb-1">Rice Variety &amp; Bag Quantity</label>
              <input type="text" name="variety_quantity" required placeholder="e.g. 1121 Steam 100 Bags (50kg)" class="w-full text-sm px-3.5 py-2.5 rounded-lg border border-stone-300 focus:ring-2 focus:ring-emerald-800 focus:outline-none bg-white">
            </div>
            <button type="submit" class="w-full bg-emerald-800 hover:bg-emerald-900 text-amber-300 font-bold py-3 px-4 rounded-xl text-sm transition shadow-sm">
              Submit Wholesale Rate Request &rarr;
            </button>
          </form>
        </div>
      </div>
    </div>
  </section>

  <!-- 6. Major Cities Sourcing Hub Banner -->
  <section class="py-12 bg-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="bg-gradient-to-r from-emerald-950 via-emerald-900 to-emerald-950 rounded-2xl p-8 sm:p-10 text-white flex flex-col md:flex-row items-center justify-between gap-6 shadow-md border border-emerald-800">
        <div class="max-w-2xl">
          <span class="text-xs font-bold text-amber-300 uppercase tracking-widest">Nationwide Supply Corridors</span>
          <h2 class="font-serif text-2xl sm:text-3xl font-bold text-white mt-1">
            Pakistan 60+ Cities Wholesale Rice Supply Hub
          </h2>
          <p class="text-sm text-emerald-100/90 mt-2 leading-relaxed">
            Direct ex-mill daily bilty dispatches to wholesale grain markets and commercial caterers across Punjab, Sindh, KPK &amp; Balochistan.
          </p>
        </div>
        <a href="<?php echo esc_url(home_url('/locations')); ?>" class="px-6 py-3.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-emerald-950 font-bold text-sm transition shadow-lg shrink-0 flex items-center gap-2">
          <span>Explore Major Cities Hub</span>
          <span>&rarr;</span>
        </a>
      </div>
    </div>
  </section>
</main>
<?php
get_footer();
