<?php
/**
 * Single Post Template - Hashir Rice Supplier
 */
if (!defined('ABSPATH')) { exit; }
get_header();
?>
<main id="main-content" class="py-12 bg-stone-50">
  <div class="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
    <nav aria-label="Breadcrumb" class="text-xs text-neutral-500 mb-6 flex items-center gap-2">
      <a href="<?php echo esc_url(home_url('/')); ?>" class="hover:text-emerald-800">Home</a>
      <span>&gt;</span>
      <a href="<?php echo esc_url(home_url('/blog')); ?>" class="hover:text-emerald-800">Knowledge Blog</a>
      <span>&gt;</span>
      <span class="text-neutral-800 font-medium"><?php the_title(); ?></span>
    </nav>

    <article class="bg-white rounded-2xl border border-stone-200 p-8 sm:p-12 shadow-sm">
      <header class="border-b border-stone-200 pb-6 mb-8">
        <span class="text-xs font-bold text-emerald-800 uppercase tracking-wider">Mandi Knowledge &amp; Research</span>
        <h1 class="font-serif text-2xl sm:text-3xl font-extrabold text-emerald-950 mt-2 mb-4 leading-tight">
          <?php the_title(); ?>
        </h1>
        <div class="flex items-center gap-3 text-xs text-neutral-500">
          <span>By <strong>Muhammad Amir Shahzad</strong></span>
          <span>•</span>
          <span>Noor Galla Mandi, Bucheki</span>
          <span>•</span>
          <span><?php echo get_the_date(); ?></span>
        </div>
      </header>

      <div class="prose prose-emerald max-w-none text-neutral-800 leading-relaxed text-sm sm:text-base">
        <?php
        if (have_posts()) {
          while (have_posts()) {
            the_post();
            the_content();
          }
        }
        ?>
      </div>
    </article>
  </div>
</main>
<?php
get_footer();
