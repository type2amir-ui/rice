<?php
/**
 * Footer Template - Hashir Rice Supplier (Exact Google Studio Match)
 */
if (!defined('ABSPATH')) { exit; }
?>
<footer class="bg-white text-neutral-800 pt-14 pb-12 border-t border-neutral-200 mt-16">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <!-- Top Sourcing Callout Banner -->
    <div class="bg-emerald-50 rounded-2xl p-6 sm:p-8 mb-14 border border-emerald-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
      <div>
        <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 text-xs font-bold uppercase tracking-wider mb-2 border border-emerald-200">
          <svg class="w-3.5 h-3.5 text-emerald-700" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
          Direct Mandi Sourcing Desk
        </div>
        <h3 class="text-xl sm:text-2xl font-serif font-bold text-neutral-950 tracking-tight">
          Direct Sourcing from Noor Galla Mandi Bucheki
        </h3>
        <p class="text-neutral-600 text-sm mt-1 max-w-xl">
          1121 Kainat, Super Kernel Basmati, 1509 &amp; IRRI-6 with transparent mandi brokerage and verified bilty delivery across 60+ Pakistan cities.
        </p>
      </div>

      <div class="flex flex-wrap items-center gap-3 w-full md:w-auto">
        <a href="https://trade.hashirricesupplier.com/" target="_blank" rel="noopener noreferrer" class="w-full sm:w-auto px-5 py-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-sm shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer">
          <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          <span>Add your rice sample</span>
          <svg class="w-3.5 h-3.5 opacity-80 shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" x2="21" y1="14" y2="3"/></svg>
        </a>

        <a href="https://wa.me/923338990883?text=Assalam-o-Alaikum%20Hashir%20Rice,%20I%20want%20to%20request%20bulk%20rate%20quotation" target="_blank" rel="noopener noreferrer" class="w-full sm:w-auto px-5 py-3 rounded-xl bg-emerald-900 hover:bg-emerald-950 text-white font-bold text-sm shadow-sm transition-all flex items-center justify-center gap-2">
          Request Bulk Rate
        </a>
        <a href="https://wa.me/923338990883?text=Hello%20Hashir%20Rice%20Supplier,%20I%20am%20looking%20for%20bulk%20rice%20quotation." target="_blank" rel="noopener noreferrer" class="w-full sm:w-auto px-5 py-3 rounded-xl bg-white hover:bg-neutral-100 text-neutral-900 font-semibold text-sm flex items-center justify-center gap-2 border border-neutral-300 transition-all shadow-2xs">
          <svg viewBox="0 0 24 24" fill="currentColor" class="w-4 h-4 text-emerald-700 shrink-0"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.888 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
          <span>WhatsApp Direct</span>
        </a>
      </div>
    </div>

    <!-- Multi-Column Grid (Light Theme) -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-neutral-200">
      <!-- Col 1: Profile & Retail Store -->
      <div class="lg:col-span-2 space-y-4">
        <div class="flex items-center gap-3">
          <div class="relative inline-flex items-center shrink-0">
            <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-12 h-12 shrink-0 drop-shadow-sm">
              <rect x="4" y="4" width="92" height="92" rx="22" fill="#064E3B"/>
              <rect x="27" y="25" width="11" height="50" rx="5.5" fill="#FFFFFF"/>
              <rect x="62" y="25" width="11" height="50" rx="5.5" fill="#FFFFFF"/>
              <path d="M38 50 C44 43, 56 43, 62 50 C56 57, 44 57, 38 50 Z" fill="#F59E0B"/>
            </svg>
          </div>
          <div>
            <div class="flex items-center gap-1.5 leading-none">
              <span class="font-sans text-xl font-black tracking-tight text-neutral-950">HASHIR</span>
              <span class="font-sans text-xl font-black tracking-tight text-amber-600">RICE</span>
              <span class="text-[10px] font-extrabold uppercase px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-900 tracking-wider">SUPPLIER</span>
            </div>
            <p class="text-xs text-emerald-900 font-semibold mt-1">Quality • Trust • Commitment | Wholesale Rice Supplier Pakistan</p>
          </div>
        </div>

        <p class="text-xs text-neutral-600 leading-relaxed">
          <strong>Hashir Rice Supplier</strong> is a leading <strong>Wholesale Rice Supplier Pakistan</strong> and <strong>Wholesale Rice Trader Pakistan</strong>. We connect grain merchants, restaurant chains, and bulk buyers with certified Punjab and Sindh rice mills for 1121 Basmati, Super Kernel, PK-386, and IRRI varieties on transparent brokerage terms.
        </p>

        <!-- Our Retail Store Callout -->
        <div class="bg-amber-50/70 rounded-xl p-3 border border-amber-200/80 text-xs flex items-start gap-2.5">
          <div class="w-4 h-4 text-amber-800 shrink-0 mt-0.5">🏪</div>
          <div>
            <span class="font-bold text-neutral-900 block">
              Our Retail Store: <span class="text-amber-950 font-extrabold">Royal Basmati Rice</span>
            </span>
            <p class="text-neutral-600 text-[11px] leading-normal mt-0.5">
              Looking for retail consumer packs or family dining quantities? Visit our dedicated retail store <strong>Royal Basmati Rice</strong> for authentic premium aged Basmati.
            </p>
          </div>
        </div>

        <div class="bg-emerald-50 rounded-xl p-3.5 border border-emerald-200 text-xs space-y-1.5 text-neutral-700">
          <div class="font-bold text-emerald-950">Noor Galla Mandi Bucheki Physical Trading Desk</div>
          <p class="text-neutral-600">Shop #14-16, Noor Galla Mandi, Bucheki, District Nankana Sahib, Punjab</p>
          <div class="flex flex-wrap gap-x-4 gap-y-1 pt-1 font-semibold text-emerald-900">
            <span>Proprietor: Muhammad Amir Shahzad</span>
            <span>📞 +92 333 8990883</span>
            <span>📞 +92 300 2861297</span>
          </div>
        </div>
      </div>

      <!-- Col 2: Wholesale Varieties -->
      <div>
        <h4 class="font-serif font-bold text-sm text-neutral-950 mb-3 border-b border-neutral-200 pb-2">Rice Varieties</h4>
        <ul class="space-y-2 text-xs text-neutral-600">
          <li><a href="<?php echo esc_url(home_url('/varieties')); ?>" class="hover:text-emerald-900 transition">1121 Kainat Steam (8.4mm+)</a></li>
          <li><a href="<?php echo esc_url(home_url('/varieties')); ?>" class="hover:text-emerald-900 transition">1121 Golden Sella (Parboiled)</a></li>
          <li><a href="<?php echo esc_url(home_url('/varieties')); ?>" class="hover:text-emerald-900 transition">1121 Creamy Sella Basmati</a></li>
          <li><a href="<?php echo esc_url(home_url('/varieties')); ?>" class="hover:text-emerald-900 transition">Super Kernel Basmati (Aged)</a></li>
          <li><a href="<?php echo esc_url(home_url('/varieties')); ?>" class="hover:text-emerald-900 transition">1509 Long Grain Basmati</a></li>
          <li><a href="<?php echo esc_url(home_url('/varieties')); ?>" class="hover:text-emerald-900 transition">IRRI-6 White Rice</a></li>
          <li><a href="<?php echo esc_url(home_url('/varieties')); ?>" class="hover:text-emerald-900 transition">Broken Rice Totta (B1 Sortex)</a></li>
        </ul>
      </div>

      <!-- Col 3: Major Cities -->
      <div>
        <h4 class="font-serif font-bold text-sm text-neutral-950 mb-3 border-b border-neutral-200 pb-2">Major Cities Hub</h4>
        <ul class="space-y-2 text-xs text-neutral-600">
          <li><a href="<?php echo esc_url(home_url('/locations')); ?>" class="hover:text-emerald-900 transition">Lahore (Akbari Mandi)</a></li>
          <li><a href="<?php echo esc_url(home_url('/locations')); ?>" class="hover:text-emerald-900 transition">Karachi (Jodia Bazar)</a></li>
          <li><a href="<?php echo esc_url(home_url('/locations')); ?>" class="hover:text-emerald-900 transition">Rawalpindi &amp; Islamabad</a></li>
          <li><a href="<?php echo esc_url(home_url('/locations')); ?>" class="hover:text-emerald-900 transition">Faisalabad (Dhanola Galla Mandi)</a></li>
          <li><a href="<?php echo esc_url(home_url('/locations')); ?>" class="hover:text-emerald-900 transition">Peshawar (Rampura Gate)</a></li>
          <li><a href="<?php echo esc_url(home_url('/locations')); ?>" class="hover:text-emerald-900 transition">Quetta &amp; 60+ Cities Network</a></li>
        </ul>
      </div>

      <!-- Col 4: Commercial Desk -->
      <div>
        <h4 class="font-serif font-bold text-sm text-neutral-950 mb-3 border-b border-neutral-200 pb-2">Commercial Desk</h4>
        <ul class="space-y-2 text-xs text-neutral-600">
          <li><a href="<?php echo esc_url(home_url('/exchange')); ?>" class="hover:text-emerald-900 transition font-bold text-emerald-800">Live Mandi Rates Ticker</a></li>
          <li><a href="<?php echo esc_url(home_url('/sample-request')); ?>" class="hover:text-emerald-900 transition">Order Cooking Sample</a></li>
          <li><a href="<?php echo esc_url(home_url('/workflow')); ?>" class="hover:text-emerald-900 transition">7-Stage Sourcing Quality</a></li>
          <li><a href="<?php echo esc_url(home_url('/seller-portal')); ?>" class="hover:text-emerald-900 transition">Millers &amp; Sellers Portal</a></li>
          <li><a href="<?php echo esc_url(home_url('/reviews')); ?>" class="hover:text-emerald-900 transition">Client Reviews &amp; Ratings</a></li>
          <li><a href="<?php echo esc_url(home_url('/faqs')); ?>" class="hover:text-emerald-900 transition">Wholesale FAQs</a></li>
          <li><a href="<?php echo esc_url(home_url('/contact')); ?>" class="hover:text-emerald-900 transition">Contact Bucheki Desk</a></li>
        </ul>
      </div>
    </div>

    <!-- Bottom Copyright -->
    <div class="pt-8 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-neutral-500">
      <p>&copy; <?php echo date('Y'); ?> Hashir Rice Supplier. All rights reserved. Noor Galla Mandi, Bucheki (Nankana Sahib, Punjab, Pakistan).</p>
      <div class="flex items-center gap-4">
        <span>Verified Mandi Trader #418</span>
        <span>•</span>
        <span>100% Buhler Sortex Guarantee</span>
      </div>
    </div>
  </div>
</footer>

<!-- Floating WhatsApp CTA Button (Sticky Bottom Right) -->
<aside aria-label="Direct WhatsApp Contact" class="fixed bottom-6 right-6 z-50">
  <a href="https://wa.me/923338990883?text=Assalam-o-Alaikum%20Hashir%20Rice%20Supplier,%20I%20want%20to%20inquire%20about%20wholesale%20rates" target="_blank" rel="noopener noreferrer" class="flex items-center gap-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-5 py-3.5 rounded-full shadow-2xl transition hover:scale-105 border-2 border-white" aria-label="Chat on WhatsApp with Mandi Desk">
    <span class="text-2xl leading-none">💬</span>
    <span class="text-sm font-bold tracking-wide hidden sm:inline">WhatsApp Mandi Desk</span>
  </a>
</aside>

<script>
document.addEventListener('DOMContentLoaded', function() {
  var toggle = document.getElementById('mobile-menu-toggle');
  var panel = document.getElementById('mobile-nav-panel');
  if (toggle && panel) {
    toggle.addEventListener('click', function() {
      panel.classList.toggle('hidden');
    });
  }

  // Mandi rate tab filtering
  var rateTabs = document.querySelectorAll('.rate-tab-btn');
  var rateRows = document.querySelectorAll('.rate-row');
  if (rateTabs.length && rateRows.length) {
    rateTabs.forEach(function(tab) {
      tab.addEventListener('click', function() {
        var filter = this.getAttribute('data-filter');
        rateTabs.forEach(function(t) {
          t.className = 'rate-tab-btn px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer bg-white text-stone-700 hover:bg-stone-100 border border-stone-200';
        });
        this.className = 'rate-tab-btn px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer bg-emerald-900 text-amber-300 shadow-xs border border-emerald-800';
        rateRows.forEach(function(row) {
          if (filter === 'all' || row.getAttribute('data-category') === filter) {
            row.style.display = '';
          } else {
            row.style.display = 'none';
          }
        });
      });
    });
  }
});
</script>

</div><!-- /#root -->

<?php wp_footer(); ?>
</body>
</html>
