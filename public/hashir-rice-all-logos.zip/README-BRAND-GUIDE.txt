========================================================================
HASHIR RICE SUPPLIER - OFFICIAL BRAND ASSETS & SOCIAL MEDIA MEDIA KIT
========================================================================

Company: Hashir Rice Supplier
Website: https://ais-pre-64yyrqslkoc5awixfgtime-597694590434.asia-southeast1.run.app
Phone / WhatsApp: +92 309 6868666
Email: hashirricesuppliers@gmail.com
Location: Karachi Wholesale Rice Mandi & Ex-Mill Punjab Mandis (Kamoke, Hafizabad)

1. GOOGLE MY BUSINESS (GMB) / GOOGLE MAPS
   - Profile Logo: hashir-rice-google-business-logo-1200x1200.jpg (or .png)
     * Recommended Upload: Square 1:1 format, crisp contrast for Google Maps pin.
   - Cover Photo: hashir-rice-google-business-cover-1024x576.jpg
     * Recommended Upload: 16:9 ratio, displays at top of your Google Knowledge Panel.

2. FACEBOOK PAGE
   - Profile Picture: hashir-rice-facebook-profile-1080x1080.jpg (or .png)
     * Recommended Upload: 1080x1080 px (centers cleanly inside the circle crop).
   - Cover Banner: hashir-rice-facebook-cover-1640x624.jpg
     * Recommended Upload: Safe zone compliant for both desktop and mobile app.

3. LINKEDIN COMPANY PAGE
   - Profile Logo: hashir-rice-linkedin-profile-800x800.jpg (or .png)
     * Recommended Upload: Square 800x800 px for corporate credibility.
   - Company Cover Banner: hashir-rice-linkedin-cover-1584x396.jpg
     * Recommended Upload: 1584x396 px official LinkedIn Company Page Banner.

4. WEBSITE & CORPORATE BANNERS
   - Panoramic Full HD Banner: hashir-rice-website-banner-1920x1080.jpg
   - Photographic Corporate Burlap Banner: hashir-rice-photographic-banner-16x9.jpg
   - Horizontal Brand Lockup: hashir-rice-horizontal-lockup.png (and .svg)
   - Transparent Master Emblem: hashir-rice-transparent-logo.png (for invoices, letters, bags)

5. VECTOR MASTER FILES (Infinite Scaling)
   - hashir-rice-master-emblem.svg
   - hashir-rice-horizontal-lockup.svg
   - hashir-rice-panoramic-website-banner.svg

All assets are certified under Hashir Rice Supplier visual identity standards.
========================================================================
